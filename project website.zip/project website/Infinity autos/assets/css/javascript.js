btn=()=>{
    let btn=document.getElementById("cnt-btn");
btn.innerHTML="Submitted";
alert("Make sure you have submitted all the Fileds!Otherwise Your Ip will be Stored");
};